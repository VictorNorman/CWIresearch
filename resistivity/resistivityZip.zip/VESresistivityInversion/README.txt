Te execute the inverse program double-click on WindowsVESinverse.exe. Input the "txt" data file created in the
WinResDataInput.exe program. You may have to wait a few minutes for the program to complete.
To look at the predicted best fit for the number of iterations given click "View Predicted Model".
To plot the fit to the data click "Plot the Curves" and then "Open File". The default output file from the program is
called VESinverseOUT.csv and that should normally be selected for the plot.