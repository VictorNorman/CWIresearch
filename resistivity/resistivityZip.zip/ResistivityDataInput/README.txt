To execute this program double click on WinResDataInput.exe
After all of the data are entered click on "Save Resistivity File" to make the "txt" file
necessary as input for other resistivity interpretation programs. 