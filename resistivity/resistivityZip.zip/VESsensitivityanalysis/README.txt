To execute this program double click on WindowsVEScurves.exe
The input should be the output from the WinResDataInput.exe program. It will be a "txt' file
To Plot the results "Select the Resistivity Data file" which is by default written to the VESOUT.csv
file.